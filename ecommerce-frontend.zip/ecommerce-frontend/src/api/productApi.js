const BASE_URL = 'http://localhost:8080/api/products'

async function handleResponse(res) {
  if (!res.ok) {
    let message = `Request failed with status ${res.status}`
    try {
      const body = await res.json()
      if (body?.message) message = body.message
      else if (typeof body === 'string') message = body
    } catch {
      // response wasn't JSON — keep default message
    }
    throw new Error(message)
  }
  // DELETE returns a plain string, everything else returns JSON
  const contentType = res.headers.get('content-type') || ''
  if (contentType.includes('application/json')) return res.json()
  return res.text()
}

export const productApi = {
  getAll: () => fetch(BASE_URL).then(handleResponse),

  getById: (id) => fetch(`${BASE_URL}/${id}`).then(handleResponse),

  create: (product) =>
    fetch(BASE_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(product),
    }).then(handleResponse),

  update: (id, product) =>
    fetch(`${BASE_URL}/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(product),
    }).then(handleResponse),

  remove: (id) =>
    fetch(`${BASE_URL}/${id}`, { method: 'DELETE' }).then(handleResponse),
}
