const STOCK_GAUGE_CAP = 50
const LOW_STOCK_THRESHOLD = 10

function formatPrice(price) {
  return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(price)
}

export default function ProductList({ products, onEdit, onDelete }) {
  if (products.length === 0) {
    return (
      <div className="state-block">
        <strong>Manifest is empty</strong>
        Add a product to start the ledger.
      </div>
    )
  }

  return (
    <div className="manifest">
      <div className="manifest-row head">
        <span>SKU</span>
        <span>Product</span>
        <span>Category</span>
        <span>Price</span>
        <span>Stock</span>
        <span></span>
      </div>

      {products.map((product) => {
        const fillPct = Math.min((product.stock / STOCK_GAUGE_CAP) * 100, 100)
        const isLow = product.stock < LOW_STOCK_THRESHOLD

        return (
          <div className="manifest-row" key={product.id}>
            <span className="tag-id">SKU-{String(product.id).padStart(4, '0')}</span>

            <div className="row-name">
              <strong>{product.name}</strong>
              <span className="row-desc">{product.description}</span>
            </div>

            <span className="row-category">{product.category}</span>

            <span className="row-price">{formatPrice(product.price)}</span>

            <div className="stock-gauge">
              <span className="stock-gauge-label">{product.stock} units</span>
              <div className="stock-gauge-bar">
                <div
                  className={`stock-gauge-fill${isLow ? ' low' : ''}`}
                  style={{ width: `${fillPct}%` }}
                />
              </div>
            </div>

            <div className="row-actions">
              <button className="btn btn-sm" onClick={() => onEdit(product)}>Edit</button>
              <button className="btn btn-sm btn-warn" onClick={() => onDelete(product)}>Delete</button>
            </div>
          </div>
        )
      })}
    </div>
  )
}
