import { useState } from 'react'

const emptyProduct = {
  name: '',
  description: '',
  price: '',
  category: '',
  stock: '',
  imageUrl: '',
}

function validate(values) {
  const errors = {}
  if (!values.name.trim()) errors.name = 'Product name is required'
  if (!values.description.trim()) errors.description = 'Description required'
  if (values.price === '' || Number(values.price) <= 0)
    errors.price = 'Price must be greater than 0'
  if (!values.category.trim()) errors.category = 'Category is required'
  if (values.stock === '' || Number(values.stock) < 0)
    errors.stock = 'Stock cannot be negative'
  return errors
}

export default function ProductForm({ initialProduct, onSave, onCancel, saving }) {
  const isEdit = Boolean(initialProduct)
  const [values, setValues] = useState(
    initialProduct
      ? {
          name: initialProduct.name ?? '',
          description: initialProduct.description ?? '',
          price: initialProduct.price ?? '',
          category: initialProduct.category ?? '',
          stock: initialProduct.stock ?? '',
          imageUrl: initialProduct.imageUrl ?? '',
        }
      : emptyProduct
  )
  const [errors, setErrors] = useState({})

  function handleChange(field, value) {
    setValues((prev) => ({ ...prev, [field]: value }))
  }

  function handleSubmit(e) {
    e.preventDefault()
    const validationErrors = validate(values)
    setErrors(validationErrors)
    if (Object.keys(validationErrors).length > 0) return

    onSave({
      ...values,
      price: Number(values.price),
      stock: Number(values.stock),
    })
  }

  return (
    <div className="overlay" onMouseDown={(e) => { if (e.target === e.currentTarget) onCancel() }}>
      <div className="slip">
        <div className="slip-sub">{isEdit ? `Amend entry · SKU-${String(initialProduct.id).padStart(4, '0')}` : 'New manifest entry'}</div>
        <h2 className="slip-title">{isEdit ? 'Edit product' : 'Add product'}</h2>

        <form onSubmit={handleSubmit} noValidate>
          <div className="field">
            <label htmlFor="name">Name</label>
            <input
              id="name"
              value={values.name}
              onChange={(e) => handleChange('name', e.target.value)}
              placeholder="e.g. Canvas Tote Bag"
            />
            {errors.name && <div className="field-error">{errors.name}</div>}
          </div>

          <div className="field">
            <label htmlFor="description">Description</label>
            <textarea
              id="description"
              value={values.description}
              onChange={(e) => handleChange('description', e.target.value)}
              placeholder="What makes this product worth stocking"
            />
            {errors.description && <div className="field-error">{errors.description}</div>}
          </div>

          <div className="field-row">
            <div className="field">
              <label htmlFor="price">Price</label>
              <input
                id="price"
                type="number"
                step="0.01"
                min="0"
                value={values.price}
                onChange={(e) => handleChange('price', e.target.value)}
                placeholder="0.00"
              />
              {errors.price && <div className="field-error">{errors.price}</div>}
            </div>
            <div className="field">
              <label htmlFor="stock">Stock</label>
              <input
                id="stock"
                type="number"
                min="0"
                value={values.stock}
                onChange={(e) => handleChange('stock', e.target.value)}
                placeholder="0"
              />
              {errors.stock && <div className="field-error">{errors.stock}</div>}
            </div>
          </div>

          <div className="field">
            <label htmlFor="category">Category</label>
            <input
              id="category"
              value={values.category}
              onChange={(e) => handleChange('category', e.target.value)}
              placeholder="e.g. Bags"
            />
            {errors.category && <div className="field-error">{errors.category}</div>}
          </div>

          <div className="field">
            <label htmlFor="imageUrl">Image URL (optional)</label>
            <input
              id="imageUrl"
              value={values.imageUrl}
              onChange={(e) => handleChange('imageUrl', e.target.value)}
              placeholder="https://…"
            />
          </div>

          <div className="slip-actions">
            <button type="submit" className="btn btn-primary" disabled={saving}>
              {saving ? 'Saving…' : isEdit ? 'Save changes' : 'Add to manifest'}
            </button>
            <button type="button" className="btn btn-ghost" onClick={onCancel} disabled={saving}>
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
