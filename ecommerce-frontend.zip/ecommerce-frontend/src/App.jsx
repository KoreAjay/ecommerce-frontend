import { useEffect, useMemo, useState } from 'react'
import { productApi } from './api/productApi'
import ProductList from './components/ProductList'
import ProductForm from './components/ProductForm'

export default function App() {
  const [products, setProducts] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [search, setSearch] = useState('')

  const [formOpen, setFormOpen] = useState(false)
  const [editingProduct, setEditingProduct] = useState(null)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    loadProducts()
  }, [])

  async function loadProducts() {
    setLoading(true)
    setError(null)
    try {
      const data = await productApi.getAll()
      setProducts(data)
    } catch (err) {
      setError(`Couldn't load the manifest — ${err.message}. Is the backend running on port 8080?`)
    } finally {
      setLoading(false)
    }
  }

  function openCreateForm() {
    setEditingProduct(null)
    setFormOpen(true)
  }

  function openEditForm(product) {
    setEditingProduct(product)
    setFormOpen(true)
  }

  function closeForm() {
    setFormOpen(false)
    setEditingProduct(null)
  }

  async function handleSave(values) {
    setSaving(true)
    setError(null)
    try {
      if (editingProduct) {
        const updated = await productApi.update(editingProduct.id, values)
        setProducts((prev) => prev.map((p) => (p.id === updated.id ? updated : p)))
      } else {
        const created = await productApi.create(values)
        setProducts((prev) => [...prev, created])
      }
      closeForm()
    } catch (err) {
      setError(`Couldn't save the product — ${err.message}`)
    } finally {
      setSaving(false)
    }
  }

  async function handleDelete(product) {
    const confirmed = window.confirm(`Remove "${product.name}" from the manifest? This can't be undone.`)
    if (!confirmed) return

    setError(null)
    try {
      await productApi.remove(product.id)
      setProducts((prev) => prev.filter((p) => p.id !== product.id))
    } catch (err) {
      setError(`Couldn't delete the product — ${err.message}`)
    }
  }

  const filteredProducts = useMemo(() => {
    const term = search.trim().toLowerCase()
    if (!term) return products
    return products.filter(
      (p) =>
        p.name.toLowerCase().includes(term) ||
        p.category.toLowerCase().includes(term)
    )
  }, [products, search])

  return (
    <div className="app">
      <header className="masthead">
        <div>
          <h1 className="masthead-title">Stockroom</h1>
          <div className="masthead-sub">Product manifest &amp; ledger</div>
        </div>
        <div className="masthead-meta">
          <div><strong>{products.length}</strong> items on manifest</div>
          <div>localhost:8080/api/products</div>
        </div>
      </header>

      {error && <div className="error-banner">{error}</div>}

      <div className="toolbar">
        <input
          className="search-input"
          type="text"
          placeholder="Search by name or category…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          aria-label="Search products"
        />
        <button className="btn btn-primary" onClick={openCreateForm}>+ Add product</button>
      </div>

      {loading ? (
        <div className="state-block">
          <strong>Reading the ledger…</strong>
          Fetching products from the backend.
        </div>
      ) : (
        <ProductList
          products={filteredProducts}
          onEdit={openEditForm}
          onDelete={handleDelete}
        />
      )}

      {formOpen && (
        <ProductForm
          initialProduct={editingProduct}
          onSave={handleSave}
          onCancel={closeForm}
          saving={saving}
        />
      )}
    </div>
  )
}
